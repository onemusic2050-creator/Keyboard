# My Custom Keyboard (Android IME starter)

This is an Android Studio project starter for a custom keyboard. It includes the uploaded Myfont-Regular.ttf in assets and initial output mappings:
- a -> Ⲁ
- b -> 𐐺
- w -> ယ
- x -> ⴳ

All other letters currently output standard Latin characters. The included PDF template is a Calligraphr grid, not a complete character map/font data source; the provided TTF is the actual font asset used to style the key labels.

## Build
Open this folder in Android Studio, sync Gradle, then Build > Build APK(s). Install the resulting APK and enable it in Settings > System > Languages & input > On-screen keyboard (menu names vary by Android version/device).

This starter project has not been built or tested in Android Studio in this environment. Review and test the IME before installing/using it. It is a local keyboard and does not contain networking code.
