package com.example.mycustomkeyboard;

import android.inputmethodservice.InputMethodService;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.util.TypedValue;
import java.util.HashMap;

public class CustomKeyboardService extends InputMethodService {
    private boolean symbols = false;
    private boolean caps = false;
    private Typeface customTypeface;
    private final HashMap<String,String> replacements = new HashMap<>();
    @Override public void onCreate() {
        super.onCreate();
        replacements.put("a", "Ⲁ"); replacements.put("b", "𐐺"); replacements.put("w", "ယ"); replacements.put("x", "ⴳ");
        try { customTypeface = Typeface.createFromAsset(getAssets(), "fonts/custom.ttf"); } catch(Exception ignored) {}
    }
    @Override public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(4),dp(5),dp(4),dp(5)); root.setBackgroundColor(Color.rgb(35,38,43));
        String[][] rows = symbols ? new String[][]{{"1","2","3","4","5","6","7","8","9","0"},{"@","#","$","%","&","-","+","(",")","/"},{"*","\u0022","'",":",";","!","?","⌫"}} : new String[][]{{"q","w","e","r","t","y","u","i","o","p"},{"a","s","d","f","g","h","j","k","l"},{"⇧","z","x","c","v","b","n","m","⌫"}};
        for (String[] row : rows) { LinearLayout line = new LinearLayout(this); line.setGravity(Gravity.CENTER); for(String k:row) line.addView(key(k), new LinearLayout.LayoutParams(0,dp(48),1)); root.addView(line); }
        LinearLayout bottom = new LinearLayout(this); bottom.setGravity(Gravity.CENTER);
        bottom.addView(key("?123"), new LinearLayout.LayoutParams(0,dp(48),1)); bottom.addView(key("🌐"),new LinearLayout.LayoutParams(0,dp(48),1)); bottom.addView(key("space"),new LinearLayout.LayoutParams(0,dp(48),4)); bottom.addView(key("↵"),new LinearLayout.LayoutParams(0,dp(48),1)); root.addView(bottom);
        return root;
    }
    private Button key(String label) {
        Button b = new Button(this); b.setText(label.equals("space")?" ":label); b.setAllCaps(false); b.setTextSize(TypedValue.COMPLEX_UNIT_SP,20); b.setTextColor(Color.WHITE);
        if(customTypeface!=null) b.setTypeface(customTypeface);
        GradientDrawable bg=new GradientDrawable(); bg.setColor(label.equals("space")?Color.rgb(55,58,63):Color.rgb(70,74,80)); bg.setCornerRadius(dp(6)); b.setBackground(bg); b.setPadding(0,0,0,0);
        b.setOnClickListener(v->{
            if(label.equals("⇧")){caps=!caps; setInputView(onCreateInputView()); return;}
            if(label.equals("?123")){symbols=!symbols; setInputView(onCreateInputView()); return;}
            if(label.equals("🌐")){ try { switchToNextInputMethod(false); } catch(Exception ignored){} return; }
            if(label.equals("⌫")){ getCurrentInputConnection().deleteSurroundingText(1,0); return; }
            if(label.equals("↵")){ getCurrentInputConnection().sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER)); return; }
            if(label.equals("space")){ getCurrentInputConnection().commitText(" ",1); return; }
            String out=label;
            if(!symbols && replacements.containsKey(label)) out=replacements.get(label);
            else if(caps && label.length()==1) out=label.toUpperCase();
            getCurrentInputConnection().commitText(out,1);
        }); return b;
    }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density); }
}
